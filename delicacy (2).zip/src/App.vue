 <template>
  <RouterView />
</template>
 <!-- <script lang="ts">
    import request from '@/utils/axios';
    const requestRes = async () => {
        let result = await request({
                    url: '/api/xxx',
                    method: 'get'
                  });
    }

</script> -->
<style>
@import "./assets/css/reset.css";
</style>

